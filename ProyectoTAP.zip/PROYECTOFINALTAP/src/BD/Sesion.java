/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BD;

/**
 *
 * @author mcali
 */
public class Sesion {
    private static String usuario;
    private static String contra;
    private static String rol;     // Rol del usuario (administrador o empleado)


    public static void iniciarSesion(String usuario, String contra,String rol) {
        Sesion.usuario = usuario;
        Sesion.contra = contra;
        Sesion.rol = rol;
    }

    public static String getUsuario() {
        return usuario;
    }

    public static String getContra() {
        return contra;
    }
    
    public static String getRol() {
        return rol;
    }

    public static void cerrarSesion() {
        Sesion.usuario = null;
        Sesion.contra = null;
        Sesion.rol = null;
    }
}

