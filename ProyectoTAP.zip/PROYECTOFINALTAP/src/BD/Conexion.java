/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Conexion {

    public String validarUsuario(String nombreUsuario, String contraseña) {
        String sql = "SELECT r.rolname AS rol " +
                 "FROM pg_roles r " +
                 "JOIN pg_auth_members m ON r.oid = m.roleid " +
                 "JOIN pg_roles u ON u.oid = m.member " +
                 "WHERE u.rolname = ?;";

    try (Connection conn = ConexionBD.getConnection("postgres", "123456");
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, nombreUsuario);
        ResultSet rs = pstmt.executeQuery();

        if (rs.next()) {
            // Validar conexión con las credenciales del usuario
            try (Connection userConn = ConexionBD.getConnection(nombreUsuario, contraseña)) {
                String rol = rs.getString("rol");
                return rol; // Devuelve el rol del usuario si las credenciales son correctas
            } catch (SQLException e) {
                return null; // Contraseña incorrecta
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return null; // Usuario no encontrado o error en la consulta
}
}
