/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    // Asegúrate de incluir el esquema por defecto aquí
    private static final String URL = "jdbc:postgresql://localhost:5432/proyecto?currentSchema=auto";

    public static Connection getConnection(String username, String password) throws SQLException {
        return DriverManager.getConnection(URL, username, password);
    }

    public static Connection getConnection() throws SQLException {
        String username = Sesion.getUsuario();
        String password = Sesion.getContra();
        if (username == null || password == null) {
            return getPublicConnection();
        }
        return DriverManager.getConnection(URL, username, password);
    }
    // Método para obtener la conexión de solo lectura (usuario público)
    public static Connection getPublicConnection() throws SQLException {
        String publicUser = "public_user";  // Usuario con permisos de solo lectura
        String publicPassword = "public_password"; // Contraseña de solo lectura
        return DriverManager.getConnection(URL, publicUser, publicPassword);
    }
}
