/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;
import BD.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Image;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
/**
 *
 * @author mcali
 */
public class TablaCoches {

    // Método para cargar datos sin filtros, con opción de filtrar por usuario normal o admin
    public static void cargarDatosEnTabla(JTable tabla, boolean esAdmin) {
        DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"Imagen", "Nombre", "Precio", "Año", "Stock"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hace que la tabla no sea editable
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) { // Columna de imagen
                    return ImageIcon.class;
                }
                return super.getColumnClass(columnIndex);
            }
        };
        tabla.setModel(modeloTabla);
        // Formateador de moneda
        NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(Locale.US);
        // Consulta SQL con filtro para usuarios normales
        String sql = "SELECT cd.imagen, cd.nombreCoche, cd.precio, c.año, c.stock " +
                     "FROM coches_detalle cd " +
                     "JOIN coches c ON cd.id = c.id";

        if (!esAdmin) {
            sql += " WHERE c.stock > 0 AND c.activo = TRUE";
        }

        try (Connection conn = ConexionBD.getPublicConnection(); // Usamos conexión pública
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            modeloTabla.setRowCount(0);
            while (rs.next()) {
                String rutaImagen = rs.getString("imagen");
                String nombre = rs.getString("nombreCoche");
                double precio = rs.getDouble("precio");
                int ano = rs.getInt("año");
                int stock = rs.getInt("stock");
                // Formatear el precio
                String precioFormateado = formatoMoneda.format(precio);
                // Escalar la imagen al tamaño deseado
                ImageIcon icono = null;
                if (rutaImagen != null && !rutaImagen.isEmpty()) {
                    ImageIcon originalIcon = new ImageIcon(rutaImagen);
                    Image imagenEscalada = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    icono = new ImageIcon(imagenEscalada);
                }

                // Agregar fila al modelo de la tabla
                modeloTabla.addRow(new Object[]{icono, nombre, precioFormateado, ano, stock});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Método para cargar datos con filtros y opción de filtrar por usuario normal o admin
    public static void cargarDatosEnTablaConFiltros(JTable tabla, String nombre, String minPrecio, String maxPrecio, String año, String categoria, boolean esAdmin) {
        DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"Imagen", "Nombre", "Precio", "Año", "Stock"}, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) { // Columna de imagen
                    return ImageIcon.class;
                }
                return super.getColumnClass(columnIndex);
            }
        };
        tabla.setModel(modeloTabla);

        StringBuilder sql = new StringBuilder(
            "SELECT cd.imagen, cd.nombreCoche, cd.precio, c.año, c.stock, c.categoria " +
            "FROM coches_detalle cd " +
            "JOIN coches c ON cd.id = c.id " +
            "WHERE 1=1 "
        );

        List<Object> parametros = new ArrayList<>();

        if (!nombre.isEmpty()) {
            sql.append("AND cd.nombreCoche ILIKE ? ");
            parametros.add("%" + nombre + "%");
        }
        if (!minPrecio.isEmpty()) {
            sql.append("AND cd.precio >= ? ");
            parametros.add(Double.parseDouble(minPrecio));
        }
        if (!maxPrecio.isEmpty()) {
            sql.append("AND cd.precio <= ? ");
            parametros.add(Double.parseDouble(maxPrecio));
        }
        if (!año.isEmpty()) {
            sql.append("AND c.año = ? ");
            parametros.add(Integer.parseInt(año));
        }
        if (categoria != null && !categoria.equals("Todas")) {
            sql.append("AND c.categoria = ? ");
            parametros.add(categoria);
        }

        // Filtrar coches activos y con stock > 0 para usuarios normales
        if (!esAdmin) {
            sql.append("AND c.stock > 0 AND c.activo = TRUE ");
        }

        try (Connection conn = ConexionBD.getPublicConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            // Asignar los parámetros a la consulta
            for (int i = 0; i < parametros.size(); i++) {
                pstmt.setObject(i + 1, parametros.get(i));
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String rutaImagen = rs.getString("imagen");
                    String nombreCoche = rs.getString("nombreCoche");
                    double precioCoche = rs.getDouble("precio");
                    int añoCoche = rs.getInt("año");
                    int stock = rs.getInt("stock");

                    // Escalar la imagen
                    ImageIcon icono = null;
                    if (rutaImagen != null && !rutaImagen.isEmpty()) {
                        ImageIcon originalIcon = new ImageIcon(rutaImagen);
                        Image imagenEscalada = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                        icono = new ImageIcon(imagenEscalada);
                    }

                    // Agregar fila
                    modeloTabla.addRow(new Object[]{icono, nombreCoche, precioCoche, añoCoche, stock});
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error en el formato de los filtros numéricos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void cargarDatosEnTablaPorNombre(JTable tabla, String nombre, boolean esAdmin) {
    DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"Imagen", "Nombre", "Precio", "Año", "Stock"}, 0) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return columnIndex == 0 ? ImageIcon.class : Object.class;
        }
    };
    tabla.setModel(modeloTabla);

    String sql = "SELECT cd.imagen, cd.nombreCoche, cd.precio, c.año, c.stock " +
                 "FROM coches_detalle cd " +
                 "JOIN coches c ON cd.id = c.id " +
                 "WHERE cd.nombreCoche ILIKE ?";

    // Si no es admin, filtrar solo coches activos y con stock > 0
    if (!esAdmin) {
        sql += " AND c.stock > 0 AND c.activo = TRUE";
    }

    try (Connection conn = ConexionBD.getPublicConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, "%" + nombre + "%");

        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                String rutaImagen = rs.getString("imagen");
                String nombreCoche = rs.getString("nombreCoche");
                double precioCoche = rs.getDouble("precio");
                int añoCoche = rs.getInt("año");
                int stock = rs.getInt("stock");

                // Escalar la imagen
                ImageIcon icono = null;
                if (rutaImagen != null && !rutaImagen.isEmpty()) {
                    ImageIcon originalIcon = new ImageIcon(rutaImagen);
                    Image imagenEscalada = originalIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                    icono = new ImageIcon(imagenEscalada);
                }

                // Agregar fila
                modeloTabla.addRow(new Object[]{icono, nombreCoche, precioCoche, añoCoche, stock});
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al cargar datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}

