/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import BD.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author mcali
 */
public class CocheDetalleC {
    public static CocheDetalle obtenerDetalleCoche(String nombreCoche) throws SQLException {
        String sql = "SELECT imagen, nombreCoche, caracteristicas, descripcion, precio " +
                     "FROM coches_detalle " +
                     "WHERE nombreCoche = ?";
        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nombreCoche);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    CocheDetalle detalle = new CocheDetalle();
                    detalle.setNombreCoche(rs.getString("nombreCoche"));
                    detalle.setCaracteristicas(rs.getString("caracteristicas"));
                    detalle.setDescripcion(rs.getString("descripcion"));
                    detalle.setPrecio(rs.getDouble("precio"));

                    // Cargar y escalar la imagen
                    String rutaImagen = rs.getString("imagen");
                    if (rutaImagen != null && !rutaImagen.isEmpty()) {
                        ImageIcon originalIcon = new ImageIcon(rutaImagen);
                        Image imagenEscalada = originalIcon.getImage().getScaledInstance(400, 250, Image.SCALE_SMOOTH);
                        detalle.setImagen(new ImageIcon(imagenEscalada));
                    }

                    return detalle;
                }
            }
        }
        return null; // No se encontró el coche
    }
    public static List<String> obtenerColoresCoche(String nombreCoche) throws SQLException {
        List<String> colores = new ArrayList<>();
        String sql = "SELECT UNNEST(colores) AS color " +
                     "FROM coches " +
                     "WHERE CONCAT(marca, ' ', modelo) = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, nombreCoche);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    colores.add(rs.getString("color"));
                }
            }
        }
        return colores;
    }
    public static int obtenerStockCoche(String nombreCoche) throws SQLException {
    String sql = "SELECT stock FROM coches WHERE CONCAT(marca, ' ', modelo) = ?";
    try (Connection conn = ConexionBD.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, nombreCoche);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("stock");
            }
        }
    }
    return 0; // Valor por defecto si no se encuentra el stock
}
}
