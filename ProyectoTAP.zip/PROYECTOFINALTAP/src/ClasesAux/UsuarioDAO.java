/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import BD.ConexionBD;
import BD.Sesion;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public DefaultTableModel obtenerUsuariosConActivoPrimero() {
    String usuarioActivo = Sesion.getUsuario();

    String sql = "SELECT nombre, apellido, correo, telefono, nombre_usuario, 'Administrador' AS tipo FROM administrador "
               + "UNION ALL "
               + "SELECT nombre, apellido, correo, telefono, nombre_usuario, 'Empleado' AS tipo FROM empleados";

    DefaultTableModel modelo = new DefaultTableModel(new Object[]{"Nombre", "Apellido", "Correo", "Teléfono", "Usuario", "Tipo"}, 0){
        @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hace que la tabla no sea editable
            }
    };

    List<Object[]> usuarios = new ArrayList<>();

    try (Connection conn = ConexionBD.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        while (rs.next()) {
            String nombre = rs.getString("nombre");
            String apellido = rs.getString("apellido");
            String correo = rs.getString("correo");
            String telefono = rs.getString("telefono");
            String nombreUsuario = rs.getString("nombre_usuario");
            String tipo = rs.getString("tipo");

            Object[] fila = new Object[]{nombre, apellido, correo, telefono, nombreUsuario, tipo};

            // Agregar el usuario activo al principio
            if (nombreUsuario.equals(usuarioActivo)) {
                modelo.addRow(fila);
            } else {
                usuarios.add(fila);
            }
        }

        // Agregar los demás usuarios después del usuario activo
        for (Object[] usuario : usuarios) {
            modelo.addRow(usuario);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return modelo;
}
    public DefaultTableModel obtenerUsuariosModelo(Connection conn) {
    DefaultTableModel modelo = new DefaultTableModel(new String[]{"Nombre", "Apellido", "Correo", "Teléfono", "Usuario", "Rol"}, 0){
    @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hace que la tabla no sea editable
            }
    };

    String sql = "SELECT nombre, apellido, correo, telefono, nombre_usuario, 'administrador' AS rol FROM administrador "
               + "UNION ALL "
               + "SELECT nombre, apellido, correo, telefono, nombre_usuario, 'empleado' AS rol FROM empleados";

    try (PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        while (rs.next()) {
            String nombre = rs.getString("nombre");
            String apellido = rs.getString("apellido");
            String correo = rs.getString("correo");
            String telefono = rs.getString("telefono");
            String usuario = rs.getString("nombre_usuario");
            String rol = rs.getString("rol");

            modelo.addRow(new Object[]{nombre, apellido, correo, telefono, usuario, rol});
        }

        return modelo;

    } catch (SQLException e) {
        e.printStackTrace();
        return null; // Si hay un error, se devuelve null
    }
}


}




