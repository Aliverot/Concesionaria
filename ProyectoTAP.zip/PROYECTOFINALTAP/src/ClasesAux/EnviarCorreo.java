/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import javax.swing.JOptionPane;

/**
 *
 * @author mcali
 */
public class EnviarCorreo {
    public static void enviarCorreoConAdjunto(String destinatario, String asunto, String mensaje, String rutaAdjunto) {
        
        final String remitente = "cochestap@gmail.com"; 
        final String contraseña = "flkbwcyckbevkiuf"; 

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, contraseña);
            }
        });

        try {
            // Crear el mensaje
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remitente));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject(asunto);

            // Crear el cuerpo del mensaje
            MimeBodyPart cuerpoMensaje = new MimeBodyPart();
            cuerpoMensaje.setText(mensaje);

            // Adjuntar el archivo PDF
            MimeBodyPart adjunto = new MimeBodyPart();
            DataSource fuente = new FileDataSource(rutaAdjunto);
            adjunto.setDataHandler(new DataHandler(fuente));
            adjunto.setFileName(fuente.getName());

            // Combinar el cuerpo del mensaje y el adjunto
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(cuerpoMensaje);
            multipart.addBodyPart(adjunto);

            message.setContent(multipart);

            // Enviar el mensaje
            Transport.send(message);

            JOptionPane.showMessageDialog(null, "Correo enviado exitosamente.");

        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al enviar el correo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
