/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import BD.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class TablaVentas {

    public static void cargarDatosEnTabla(JTable tabla, String nombreCliente, String nombreCoche, Date fechaVenta) {
        DefaultTableModel modeloTabla = new DefaultTableModel(new Object[]{"ID", "Fecha", "Cliente", "Coche", "Total"}, 0){
        @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Hace que la tabla no sea editable
            }
        };        
        tabla.setModel(modeloTabla);
        
        StringBuilder sql = new StringBuilder(
            "SELECT v.id, v.fecha, c.nombre || ' ' || c.apellido AS cliente, " +
            "co.marca || ' ' || co.modelo AS coche, v.total " +
            "FROM ventas v " +
            "JOIN clientes c ON v.id_cliente = c.id " +
            "JOIN coches co ON v.id_coche = co.id WHERE 1=1"
        );

        // Construir la consulta con filtros opcionales
        if (!nombreCliente.isEmpty()) {
            sql.append(" AND (c.nombre ILIKE ? OR c.apellido ILIKE ?)");
        }
        if (!nombreCoche.isEmpty()) {
            sql.append(" AND (co.marca ILIKE ? OR co.modelo ILIKE ?)");
        }
        if (fechaVenta != null) {
            sql.append(" AND v.fecha = ?");
        }

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (!nombreCliente.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + nombreCliente + "%");
                pstmt.setString(paramIndex++, "%" + nombreCliente + "%");
            }
            if (!nombreCoche.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + nombreCoche + "%");
                pstmt.setString(paramIndex++, "%" + nombreCoche + "%");
            }
            if (fechaVenta != null) {
                java.sql.Date fechaSQL = new java.sql.Date(fechaVenta.getTime());
                pstmt.setDate(paramIndex++, fechaSQL);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                DecimalFormat formato = new DecimalFormat("#,##0.00");
                while (rs.next()) {
                    int id = rs.getInt("id");
                    Date fecha = rs.getDate("fecha");
                    String cliente = rs.getString("cliente");
                    String coche = rs.getString("coche");
                    String total = "$" + formato.format(rs.getDouble("total"));

                    modeloTabla.addRow(new Object[]{id, fecha, cliente, coche, total});
                }
            }

            // Ocultar la columna ID
            tabla.getColumnModel().getColumn(0).setMinWidth(0);
            tabla.getColumnModel().getColumn(0).setMaxWidth(0);
            tabla.getColumnModel().getColumn(0).setWidth(0);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar ventas: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

