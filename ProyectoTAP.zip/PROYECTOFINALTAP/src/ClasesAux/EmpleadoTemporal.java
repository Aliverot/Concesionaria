/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

/**
 *
 * @author mcali
 */
public class EmpleadoTemporal {
    private static String nombre;
    private static String apellido;
    private static String correo;
    private static String telefono;

    public static void guardarDatos(String nombre, String apellido, String correo, String telefono) {
        EmpleadoTemporal.nombre = nombre;
        EmpleadoTemporal.apellido = apellido;
        EmpleadoTemporal.correo = correo;
        EmpleadoTemporal.telefono = telefono;
    }

    public static String getNombre() {
        return nombre;
    }

    public static String getApellido() {
        return apellido;
    }

    public static String getCorreo() {
        return correo;
    }

    public static String getTelefono() {
        return telefono;
    }

    public static void limpiarDatos() {
        nombre = null;
        apellido = null;
        correo = null;
        telefono = null;
    }
}

