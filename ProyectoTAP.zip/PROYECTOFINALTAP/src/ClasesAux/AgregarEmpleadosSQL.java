/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class AgregarEmpleadosSQL {

    public void insertarEmpleado(Connection connection, String nombre, String apellido, String correo, String telefono, String nombreUsuario, String contraseña, String rol) throws SQLException {
        String tabla = rol.equals("administrador") ? "auto.administrador" : "auto.empleados"; // Asegúrate de incluir el esquema
        String sql = "INSERT INTO " + tabla + " (nombre, apellido, correo, telefono, nombre_usuario, contraseña) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            pstmt.setString(2, apellido);
            pstmt.setString(3, correo);
            pstmt.setString(4, telefono);
            pstmt.setString(5, nombreUsuario);
            pstmt.setString(6, contraseña);
            pstmt.executeUpdate();
        }
    }

    public void crearUsuario(Connection connection, String nombreUsuario, String contraseña, String rol) throws SQLException {
        // Crear el usuario en PostgreSQL
        String sqlCrearUsuario = "CREATE USER " + nombreUsuario + " PASSWORD '" + contraseña + "' NOSUPERUSER LOGIN INHERIT";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sqlCrearUsuario);
        }

        // Asignar el rol (administrador o empleado) al usuario
        String sqlAsignarRol = "GRANT " + rol + " TO " + nombreUsuario;
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sqlAsignarRol);
        }

        // Si es administrador, otorgar el permiso CREATEROLE al nuevo usuario
        if ("administrador".equalsIgnoreCase(rol)) {
            String sqlCrearole = "ALTER ROLE " + nombreUsuario + " WITH CREATEROLE";
            try (Statement stmt = connection.createStatement()) {
                stmt.executeUpdate(sqlCrearole);
            }
        }
    }
}