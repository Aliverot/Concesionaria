/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ClasesAux;

import BD.Sesion;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class UsuarioActivoRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        // Obtener el nombre de usuario en la fila actual
        String nombreUsuario = (String) table.getValueAt(row, 4); // La columna 4 es "Usuario"

        if (nombreUsuario.equals(Sesion.getUsuario())) {
            c.setBackground(new Color(173, 216, 230)); // Color celeste para resaltar
            c.setForeground(Color.BLACK);
        } else {
            c.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
            c.setForeground(isSelected ? table.getSelectionForeground() : table.getForeground());
        }

        return c;
    }
}

